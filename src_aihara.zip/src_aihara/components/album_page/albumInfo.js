

const AlbumInfo = ({ image_url, ended_date }) => {
    return (
        <div className="max-w-sm bg-white border border-gray-200 rounded-lg shadow-lg">
            <div className="flex justify-center items-center h-64">
                <img className="object-contain h-full" src={image_url} alt="generated_image" />
            </div>

            <div className="border-t border-gray-300"></div>

            <div className="p-5">
                <div className="flex justify-center items-center">
                    <p className="mb-2 text-2xl font-bold tracking-tight text-gray-900">{ended_date}</p>
                </div>
            </div>
        </div>
    )
}


export default AlbumInfo;