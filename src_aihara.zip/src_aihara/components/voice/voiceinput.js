import { Link, useNavigate } from "react-router-dom";
import React, { useEffect, useState } from 'react';

const fetchImage = async (setItem) => {
  const searchWord = "lion";
  const res = await fetch(`https://api.tvmaze.com/search/shows?q=${searchWord}`);
  const data = await res.json();

  const item = data.find(item => item.show.image);
  if (item) {
      setItem({
          imageUrl: item.show.image.medium,
      });
  }
};

const VoiceInput = () => {

  const [item, setItem] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
      fetchImage(setItem);
  }, []);

  const handleInput = async () => {
    try {
      const response = await fetch('https://localhost:8080', {
        method: 'POST',
        headers: null,
        body: null,
      });

      const result = await response.json();
      const path = result.image
      navigate('/success', { state: { imageUrl: path } });
    } catch (error) {
      console.error('Error sending data:', error);
      navigate('/cantsave');
    }
  }

  const test = async () => {

    navigate('/success', { state: { imageUrl: item.imageUrl } });

  }

    return (
      <div>
        <div className="fixed top-4 left-2 z-10">
          <Link 
              to="/"
              className="bg-blue-500 text-white font-bold py-2 px-4 rounded hover:bg-blue-700 transition duration-300 ease-in-out"
          > ← </Link>
        </div>
        <div className="px-6 py-20 text-center text-surface bg-neutral-700 text-white">
          <h1 className="mb-6 text-5xl font-bold">音声認識</h1>
          <p className="mb-8 text-3xl font-bold">ここでは，音声を入力として画像をAIに出力させ，アルバムに追加することができます！</p>
        </div>
        <div className="container mx-auto px-8 py-10">
              <div className="flex justify-center items-center">
                  <button 
                      //onClick={test}
                      onClick={handleInput}
                      className="text-2xl bg-blue-500 text-white font-bold py-2 px-4 rounded hover:bg-blue-700 transition duration-300 ease-in-out"
                  >音声入力開始！</button>
              </div>
          </div>
        <Link to="/failure" className="bg-blue-500 text-white font-bold rounded fixed bottom-4 right-2 z-10 hover:bg-blue-700 transition duration-300 ease-in-out">
          開発用：画像作成失敗時
        </Link>
      </div>
    );
  }
export default VoiceInput;