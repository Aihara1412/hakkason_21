import React from 'react';
import {useLocation, useNavigate} from "react-router-dom";
const AlbumInfo = ({ image_url}) => {
  return (
      <div className="max-w-sm border border-gray-200 rounded-lg shadow-lg">
          <div className="flex justify-center items-center">
              <img className="object-contain" src={image_url} alt="generated_image" />
          </div>
      </div>
  );
};

const Success = () => {

  const navigate = useNavigate();
  const location = useLocation();
  const { imageUrl } = location.state || {};

  const handleSave = async () => {

    const currentTime = new Date().toISOString();

    const data = {
      photo_url: imageUrl,
      time: currentTime,
    };

    try {
      const response = await fetch('https://localhost:8080', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });

      const result = await response.json();
      console.log('Response from backend:', result.message);
      navigate('/save', { state: { imageUrl: imageUrl } });
    } catch (error) {
      console.error('Error sending data:', error);
      navigate('/cantsave');
    }
  };

  const handleNotSave = () => {
    navigate('/notsave');
  };

  const test = () => {
    navigate('/save', { state: { imageUrl: imageUrl } });
  }

  return (
    <div>
      <div className="px-6 py-20 text-center text-surface bg-neutral-700 text-white">
        <h1 className="mb-6 text-5xl font-bold">音声認識</h1>
        <p className="mb-8 text-3xl font-bold">ここでは，音声を入力として画像をAIに出力させ，アルバムに追加することができます！</p>
      </div>
      <div className="flex flex-wrap justify-center pt-8">
        <AlbumInfo image_url={imageUrl}/>
      </div>
      <p className="mb-8 text-3xl font-bold text-center pt-8"> 画像が生成されました！</p>
      <div className="container mx-auto px-8">
        <div className="flex justify-center items-center gap-4">
            <button
                onClick={handleSave}
                //onClick={test}
                className="bg-blue-500 text-white font-bold py-2 px-4 rounded hover:bg-blue-700 transition duration-300 ease-in-out"
            >保存する</button>
            <button
                onClick={handleNotSave}
                className="bg-blue-500 text-white font-bold py-2 px-4 rounded hover:bg-blue-700 transition duration-300 ease-in-out"
            >保存しない</button>
        </div>
      </div>
    </div>
  );
}
export default Success;