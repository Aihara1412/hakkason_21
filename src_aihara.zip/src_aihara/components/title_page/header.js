
const Header = () => {
    return(
        <>
            <div className="px-6 py-20 text-center text-surface bg-neutral-700 text-white">
                <h1 className="mb-6 text-5xl font-bold">アプリ名</h1>
                <p className="mb-8 text-3xl font-bold">説明</p>
            </div>
        </>
    );
}

export default Header;