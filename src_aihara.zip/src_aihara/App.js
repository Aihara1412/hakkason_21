import './App.css';
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import Title from "./components/title_page/title";
import Album from "./components/album_page/album";
import VoiceInput from "./components/voice/voiceinput";
import TextInput from "./components/textinput/textinput";
import TextFailure from "./components/textinput/textfailure";
import Success from "./components/photo/success";
import Failure from "./components/photo/failure";
import Save from "./components/save/save";
import NotSave from "./components/save/notsave";

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Title />} />
          <Route path='/album' element={<Album />} />
          <Route path="/voiceinput" element={<VoiceInput />} />
          <Route path="/textinput" element={<TextInput />} />
          <Route path="/textfailure" element={<TextFailure />} />
          <Route path="/success" element={<Success />} />
          <Route path="/failure" element={<Failure />} />
          <Route path="/save" element={<Save />} />
          <Route path="/notsave" element={<NotSave />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;