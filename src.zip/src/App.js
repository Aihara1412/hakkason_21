import './App.css';
import Album from './components/album_page/album';
import { Route, Routes } from 'react-router-dom';
import Home from './components/title_page/home';
import Dummy from './components/image-generator-dummy/dummy';
import NotFound from './components/notFound';


function App() {
  return (
    <>
      <Routes>
          <Route path="/" element={<Home />} />
          <Route path='/album' element={<Album />} />
          <Route path='/image-generator' element={<Dummy />} />
          <Route path='*' element={<NotFound />} />
      </Routes>
    </>
    
  );
}

export default App;
