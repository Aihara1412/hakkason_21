

const Dummy = () => {
    return (
        <h1>画像生成ページです。(ダミー)</h1>
    )
}

export default Dummy;